import React from 'react';
import { render } from 'react-dom';
import Booking from './components/booking';

render(<Booking />, document.getElementById('booking'));

window.Booking = Booking;
