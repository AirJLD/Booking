//TEMPLATES
// var listing = {
//   id: 0,
//   owner_id: 0,
//   review_count: 0,
//   avg_review: 0,
//   day_rate: 0,
//   service_fee: 0,
//   cleaning_fee: 0,
//   max_guests: 0,
//   avg_weekly_views: 0,
//   avg_monthly_views: 0,
//   total_views: 0
// };

// var booking = {
//   id: 0,
//   listing_id: 0,
//   customer_id: 0,
//   start_date: 0,
//   end_date: 0,
//   total_cost: 0,
//   host_booking: false
// };

// var user = {
//   id: 0,
//   name: 'John Smith'
// };

// var customer = {
//   id: 0,
//   name: 'Jane Doe'
// };